from fastapi import FastAPI, Depends
from sqlalchemy.orm import Session
from src.database.session import SessionLocal, engine, Base
from src.schemas.user import UserCreate, UserOut
from src.crud import user as crud_user

app = FastAPI()

Base.metadata.create_all(bind=engine)

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@app.post("/users/", response_model=UserOut)
def create_user(user: UserCreate, db: Session = Depends(get_db)):
    return crud_user.create_user(db, user)

@app.get("/users/", response_model=list[UserOut])
def read_users(db: Session = Depends(get_db)):
    return crud_user.get_users(db)
